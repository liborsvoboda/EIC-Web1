`TryItOut Executor` naming has changed to `HTTP client for OAS operations`. 
Please refer to new [docs/usage/http-client-for-oas-operations.md](http-client-for-oas-operations.md) documentation.
