// we're targeting browsers that already support fetch API
const { AbortController, AbortSignal } = globalThis;

export { AbortController, AbortSignal };
