import { url } from '@swagger-api/apidom-reference/configuration/empty';

const { isHttpUrl } = url;

export default isHttpUrl;
