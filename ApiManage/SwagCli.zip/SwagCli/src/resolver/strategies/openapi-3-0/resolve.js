import resolveGenericStrategy from '../generic/resolve.js';

export default async function resolveOpenAPI30Strategy(options) {
  return resolveGenericStrategy(options);
}
