import { ApiDOMStructuredError } from '@swagger-api/apidom-error';

class SchemaRefError extends ApiDOMStructuredError {}

export default SchemaRefError;
