# `@lexical/file`

[![See API Documentation](https://lexical.dev/img/see-api-documentation.svg)](https://lexical.dev/docs/api/modules/lexical_file)

This package contains the functionality for the file import/export feature of Lexical.
