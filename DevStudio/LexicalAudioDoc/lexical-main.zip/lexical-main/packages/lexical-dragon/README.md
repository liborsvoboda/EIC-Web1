# `@lexical/dragon`

[![See API Documentation](https://lexical.dev/img/see-api-documentation.svg)](https://lexical.dev/docs/api/modules/lexical_dragon)

This package contains compatibility with Dragon NaturallySpeaking accessibility tools.

More documentation coming soon.
