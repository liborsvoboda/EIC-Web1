# `@lexical/hashtag`

[![See API Documentation](https://lexical.dev/img/see-api-documentation.svg)](https://lexical.dev/docs/api/modules/lexical_hashtag)

This package contains the functionality for Lexical hashtags.

More documentation coming soon.
