# `@lexical/mark`

[![See API Documentation](https://lexical.dev/img/see-api-documentation.svg)](https://lexical.dev/docs/api/modules/lexical_mark)

This package contains helpers and nodes for wrapping content in marks for Lexical.
