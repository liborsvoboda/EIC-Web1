# `@lexical/offset`

[![See API Documentation](https://lexical.dev/img/see-api-documentation.svg)](https://lexical.dev/docs/api/modules/lexical_offset)

This package contains selection offset helpers for Lexical.
