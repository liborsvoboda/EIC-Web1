# Lexical Developer Tools review instructions:

1. Install latest LTS version of Node.js & Chrome
2. Use local copy of the source code or obtain one from https://github.com/facebook/lexical
3. Run `npm i`
4. Navigate to `/packages/lexical-devtools`
5. Run `npm run dev`
